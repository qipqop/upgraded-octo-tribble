botToken = '7951186988:AAFm2JcK5YVTvTJ6A8C0jR3deL7kvutHSXw'

channelID = '-4289319965'

db_config = 'database.db'

pyCryptoToken = "305848:AACZ6n5EZXqkPMDf45LH1IbW2Wpuou9Br6j"


menu_structure = {
    'Южно-Сахалинск': [
        {'text': 'Blender', 'callback': 'subca_4'},
        {'text': 'Unity', 'callback': 'subca_5'},
        {'text': 'EU5', 'callback': 'subca_6'}
    ],
    'Петропавловск-Камчатский': [
        {'text': 'Подкатегория 3.1', 'callback': 'subca_7'},
        {'text': 'Подкатегория 3.2', 'callback': 'subca_8'},
        {'text': 'Подкатегория 3.3', 'callback': 'subca_9'}
    ],
    'Хабаровск': [
        {'text': 'Подкатегория 4.1', 'callback': 'subca_10'},
        {'text': 'Подкатегория 4.2', 'callback': 'subca_11'},
        {'text': 'Подкатегория 4.3', 'callback': 'subca_12'}
    ],
    'Одинцово': [
        {'text': 'Подкатегория 5.1', 'callback': 'subca_13'},
        {'text': 'Подкатегория 5.2', 'callback': 'subca_14'},
        {'text': 'Подкатегория 5.3', 'callback': 'subca_15'}
    ]
}
